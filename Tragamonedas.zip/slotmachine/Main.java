import controller.SlotMachineController;
import model.*;
import view.SlotMachineView;

import javax.swing.*;
import java.util.Arrays;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            List<Symbol> symbols = Arrays.asList(
                new Symbol("🍒", 2),
                new Symbol("🍋", 3),
                new Symbol("🔔", 5),
                new Symbol("💎", 10)
            );

            SlotMachine model = new SlotMachine(3, symbols);
            SlotMachineView view = new SlotMachineView(3);
            SlotMachineController controller = new SlotMachineController(model, view);

            view.setVisible(true);
        });
    }
}
