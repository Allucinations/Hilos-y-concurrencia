package model;

public class Bet {
    private int amount;

    public Bet(int amount) {
        this.amount = amount;
    }

    public int getAmount() {
        return amount;
    }
}
